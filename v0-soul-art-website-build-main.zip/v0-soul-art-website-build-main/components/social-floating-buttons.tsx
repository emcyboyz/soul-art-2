'use client';

import { useState } from 'react';

const SOLANA_CONTRACT = '9B5X4nG3V8M2P5L8Q1K4J9H6F3C7R2S5';

export default function SocialFloatingButtons() {
  return null;
}
